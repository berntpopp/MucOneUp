# MucOneUp Test Dataset v0.25.0

## Overview

Comprehensive test dataset with **asymmetric VNTR (40/70 repeats)** across three sequencing platforms.

**Generated with**: MucOneUp v0.25.0
**Platforms**: Illumina (50×), ONT (30×), PacBio (30×)
**Sample**: Asymmetric diploid (h1=40, h2=70 repeats)
**Variants**: Normal baseline + dupC mutation

## Structure

```
testdata_40-70_v0.25.0/
├── references/          # Shared diploid references
│   ├── normal/          # Normal baseline
│   └── dupC/            # dupC mutation (h1:r20)
├── illumina/            # Illumina paired-end (50×)
│   ├── normal/
│   └── dupC/
├── ont/                 # Oxford Nanopore (30×)
│   ├── normal/
│   └── dupC/
└── pacbio/              # PacBio HiFi (30×)
    ├── normal/
    └── dupC/
```

## Quick Start

```bash
# Verify integrity
sha256sum -c checksums.txt

# Explore references
cat references/normal/testdata_40-70.001.normal.simulated.structure.tsv
cat references/dupC/testdata_40-70.001.dupC.simulated.structure.tsv

# View Illumina reads
zcat illumina/normal/reads_R1.fastq.gz | head -4

# View ONT reads
zcat ont/normal/reads.fastq.gz | head -4

# View PacBio reads
zcat pacbio/normal/reads.fastq.gz | head -4
```

## Platform Comparison

| Platform | Coverage | Read Type | VNTR-Biased |
|----------|----------|-----------|-------------|
| Illumina | 50× | Paired-end (2×150bp) | ✅ Yes |
| ONT | 30× | Long reads (~3kb) | ✅ Yes |
| PacBio | 30× | HiFi reads (~15kb) | ✅ Yes |

## Reproducibility

```bash
# Generate references (once)
muconeup --config config.json simulate \
  --out-base testdata_40-70 \
  --fixed-lengths 40 \
  --fixed-lengths 70 \
  --mutation-name normal,dupC \
  --mutation-targets 1,20 \
  --seed 42000

# Simulate Illumina (seeds: 42000 normal, 52000 dupC)
muconeup --config config.json reads illumina \
  testdata_40-70.001.normal.simulated.fa --seed 42000
muconeup --config config.json reads illumina \
  testdata_40-70.001.mut.simulated.fa --seed 52000

# Simulate ONT (seeds: 42010 normal, 52010 dupC)
muconeup --config config.json reads ont \
  testdata_40-70.001.normal.simulated.fa --seed 42010
muconeup --config config.json reads ont \
  testdata_40-70.001.mut.simulated.fa --seed 52010

# Simulate PacBio (seeds: 42020 normal, 52020 dupC)
muconeup --config config.json reads pacbio \
  testdata_40-70.001.normal.simulated.fa --seed 42020
muconeup --config config.json reads pacbio \
  testdata_40-70.001.mut.simulated.fa --seed 52020
```

## Citation

```bibtex
@software{muconeup_v0_25_0,
  author = {Popp, Bernt},
  title = {MucOneUp: MUC1 VNTR Simulation Toolkit},
  version = {v0.25.0},
  year = {2025},
  url = {https://github.com/berntpopp/MucOneUp}
}
```

## License

GPL-3.0 (same as MucOneUp)

## Support

- Documentation: https://berntpopp.github.io/MucOneUp/
- Issues: https://github.com/berntpopp/MucOneUp/issues
